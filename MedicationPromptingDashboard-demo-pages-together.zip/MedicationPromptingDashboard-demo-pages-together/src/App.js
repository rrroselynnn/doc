import React from 'react';
import './App.css';
import MedicationAdding from './MedicationAdding';
import Login from './LoginPage'
import About from './About'
import SideNav from './components/SideNav'
import CustHeader from './components/CustHeader'
import {BrowserRouter as Router,Switch, Route} from 'react-router-dom';
function App() {
    return (
      <Router> 
      <div className="App">
      {/* <div className="HeaderDivider"> 
                {CustHeader("Home")}
            </div> */}
        {/* <SideNav/> */}
      <div>
        <Switch>
        
        <Route path ='/medications' component = {MedicationAdding} />
        <Route path = '/about'  component = {About} />
        <Route path = '/login'  component = {Login} />
        <Route path = '' component = {MedicationAdding} />
        </Switch>
        </div>
        </div>
      </Router>
      
    );
}

export default App;
