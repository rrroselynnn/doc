import React from "react";
import CustHeader from './components/CustHeader'
import SideNav from './components/SideNav'
import'./About.css'

class About extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        const {classes} = this.props;
        return (
            <div className = "AboutPage">
                <div className= "HeaderDivider" >
                {CustHeader("About")}
                </div>
                <SideNav/>
               
                <div className = "AboutBody">
                  <p>
                        The UHC Medication Reminder Alexa skill and Web app are designed to help you manage your health
                        and wellness by tracking your medication schedule and
                        providing reminders to take medication according to your prescription. This skill cannot provide
                        emergency medical assistance. If you have a medical emergency,
                        please close the service and dial 911.

                        <br/> <br/>

                        This Web app allows you to view your current list of medications, add, edit, and delete
                        medications, change your medication schedule, and manage your
                        medication notifications. You may also set your time zone, phone number, and preferred day of
                        the week for your weekly “check-in” reminders.

                        <br/> <br/>

                        The Alexa skill provides voice notifications according to your medication schedule. You may also
                        use the skill to access this Web app, change your phone number,
                        peruse your notifications, and learn more about your medication through provided Web page links
                        or by speaking to a nurse via phone. For more information on the
                        skill and its capabilities, please open the skill and say “Help.”

                        <br/><br/>

                        In order to utilize the skill, you must first provide your consent and your phone number. Upon
                        your first use of the skill, Alexa will guide you through the process
                        of providing consent.

                        <br/><br/>

                        If you have further questions about the skill, or problems with the skill, please contact [UHG
                        and/or Optum] at [phone number or customer service email] or visit the
                        UHC Medical website at [URL] or the Optum website at [URL].

                    </p>  
                    </div>
                </div>
                 
        );
    }
}

export default About;
