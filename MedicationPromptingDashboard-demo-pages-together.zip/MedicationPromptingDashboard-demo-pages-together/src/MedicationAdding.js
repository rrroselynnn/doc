import React, { useState } from 'react';
import { CustHeader } from './components/CustHeader.js';
import SideNav from './components/SideNav.js';
import './MedicationAdding.css';
import { MedCard } from './components/Card.js';
import { MedModal } from './components/Modal.js';
import { DeleteAlert } from './components/DeleteAlert.js';
import FrontendMedicationSerivce from './components/FrontEndMedService.js';

const axios = require('axios');

function MedicationAdding() {
    const [prescriptions, setPrescriptions] = useState([])
    const [editIndex, setEditIndex] = useState(-2)
    const [newFlag, setNewFlag] = useState(true)
    const [formData, setFormData] = useState({ medText: '', daysArr: undefined, timesArr: undefined, dose: 0, isNew: newFlag })
    const [showAlert, setShowAlert] = useState(false)
    const [deleteIndex, setDeleteIndex] = useState(-1)

    /* Modal functions */
    function openAddModal() {
        setEditIndex(-1)
        setNewFlag(true)
    }

    function openEditModal(index) {
        setEditIndex(index)
        setNewFlag(false)
    }

    function closeModal() {
        //reset formData after an edit
        setFormData({
            medText: '',
            daysArr: [],
            timesArr: [],
            dose: 0,
            isNew: true

        })
        setEditIndex(-2)
        setNewFlag(true)
        checkIndex()
    }

    function checkIndex() {
        if (editIndex !== -2) {
            return true
        }

        return false
    }

    /* Card Functions */
    function selectEditIndex(index) {
        const currentMed = prescriptions[index]

        setFormData({
            medText: currentMed.medName,
            daysArr: (currentMed.days).split(', '),
            timesArr: currentMed.reminderTime,
            dose: currentMed.dosage,
            isNew: false

        })

        console.log(currentMed.reminderTime)

        openEditModal(index)
    }

    function changeInformation(cardData) {
        if (newFlag === true) {
            addInformation(cardData)
        }
        else {
            updateInformation(cardData)
        }

        //api call to post new med info.
    }

    /**
    * convert day strs to num for storing in dose
    * @param dayStrs: "Mon, Tues" //no trailing space
    * @returns [0,1]
    */

    function dayToNum(dayStrs) {
        var numMap = { "Sun": 0, "Mon": 1, "Tue": 2, "Wed": 3, "Thur": 4, "Fri": 5, "Sat": 6 }
        var days = []
        var sp, x;
        sp = dayStrs.split(", ")
        for (x of sp) {
            days.push(numMap[x])
        }
        return days
    }

  
     /** 
     * create dose schema
     * 
     * @param days list of days to take each dose: ie [[1,3],[1,3]]
     * @param times list of times to take each dose ie [UTC_time,UTC_time]
     * @returns json of doses for medication 
     */

    function createDoses(daysList, timesList) {
        var dose_num = 1;
        var doses_json = [];
        var new_dose;

        for (dose_num; dose_num <= daysList.length; dose_num ++) {
            new_dose = {"days": daysList[dose_num - 1], 
            "time" : timesList[dose_num -1],
            "dose_id" : dose_num}
            doses_json.push(new_dose)
            new_dose = {}
        }

        return doses_json
    }

    function addInformation(cardData) {
        setPrescriptions(prescriptions => [...prescriptions, {
            medName: cardData.inputMedText,
            days: (cardData.checkedArr).join(', '),
            reminderTime: cardData.preferredTimes,   //["8:00 am, 9:00am"]
            dosage: cardData.numberDosage           //number of times taking Med
        }])

        closeModal()
        //change time to UTC ISO string
        //console.log("PREFERRED TIMES" , cardData.preferredTimes)

        var utctimes = cardData.preferredTimes.map(time => {
            let s = time.split(':')
            let d = new Date()
            if (s[1].includes('pm' )){
                d.setHours(parseInt(s[0]) + 12)
            }
            else{
                d.setHours(parseInt(s[0]))
            }   
            d.setMinutes(0)
            d.setSeconds(0)
            return d.toISOString().slice(0,-5)
        })

        //console.log("TIMES IN UTC", utctimes)

        var dayNums = dayToNum((cardData.checkedArr).join(', '))
        var newDoses = createDoses([dayNums],utctimes)

        var newMed = { name : cardData.inputMedText,
                    doses : newDoses}
        
        
        var test_user = "john_doe"
        var test_email = "email.optum.com"
        var test_newMed = {
            user_id : test_user,
            email : test_email,
            medication : [newMed]
        }
        console.log("MED", test_newMed)


        FrontendMedicationSerivce.createMedication(test_newMed).then((result) => {
            console.log("Post success from method ", result)
        }).catch(function (error) {
            console.log("Post Error from method ", error);
          }); 
        
        //  Post without using frontendmedservice class
        //   var data = JSON.stringify({"user_id":"melissa_campbell","email":"m.campbell@optum.com","medication":[{"name":"advilwater","doses":[{"days":[1],"time":"2020-07-06T12:00:00","dose_id":1}]},{"name":"tylenol","doses":[{"days":[2,4,6],"time":"2020-07-06T12:00:00","dose_id":1},{"days":[2,4,6],"time":"2020-07-06T16:00:00","dose_id":2}]}]});
        //   var config = {
        //   method: 'post',
        //   url: 'http://localhost:8000/medications',
        //   headers: { 
        //     'Content-Type': 'application/json',
        //       'Access-Control-Allow-Origin': '*',
        //   },
        //   data : data
        //   };
        
        //   axios(config)
        //   .then(function (response) {
        //   console.log("Post success!!", JSON.stringify(response.data));
        //   })
        //   .catch(function (error) {
        //   console.log("Post Error!!!", error);
        // });

        //Get Users' Mecication, check if post was successful
        // FrontendMedicationSerivce.getMedications(test_user).then((result) => {
        //     console.log("Get success, medications found:", result.data['medication'])
        // }).catch(function (error) {
        //     console.log("Get Error");
        //   });

    }

    function updateInformation(cardData) {
        let tempArr = [...prescriptions]
        const currentMed = tempArr[editIndex]

        currentMed.medName = cardData.inputMedText
        currentMed.days = (cardData.checkedArr).join(', ')
        currentMed.reminderTime = cardData.preferredTimes
        currentMed.dosage = cardData.numberDosage

        setPrescriptions(tempArr)

        closeModal()

        //api updateMedication()
    }

    function deleteCard(index) {
        setShowAlert(false)

        let tempArr = [...prescriptions]

        tempArr.splice(index, 1)

        setPrescriptions(tempArr)

        //api deleteMedication()

    }

    /* Delete Alert functions */
    function openAlert(index) {
        setDeleteIndex(index)
        setShowAlert(true)
    }


    function handleCancelDelete() {
        setDeleteIndex(-1)
        setShowAlert(false)
    }


    return (
        <div className="MedicationAdding">
            <div className="HeaderDivider">
                {CustHeader("Medications")}
            </div>
            <SideNav />
            <div className="Body">
                {
                    ((prescriptions.length === 0) &&
                        <p className="No-Meds-Text"> You have no medications, input one by clicking the 'Add Medication' button below.</p>)
                }
                {
                    prescriptions.map((o, i) => <MedCard key={i} cardData={o} index={i} onEdit={selectEditIndex} onDelete={openAlert} />)
                }

                <button type="button" className="Add-Med-Button" onClick={openAddModal}>
                    Add Medication
                </button>

                {
                    ((editIndex !== -2) &&
                        <MedModal onChange={changeInformation} onClose={closeModal} onOpen={checkIndex} formdata={formData} />)
                }

                <DeleteAlert show={showAlert} onOKClick={() => deleteCard(deleteIndex)} onCancelClick={handleCancelDelete} />
            </div>
        </div>
    );
}

export default MedicationAdding
