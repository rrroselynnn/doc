import React from 'react';
import './SideNav.css';
import {Link} from 'react-router-dom'

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

//TODO: add links to other pages 
function SideNav() {
  return(
  <div id="mySidenav" className="sidenav">
      
      <Link to="/medications">Medications</Link>
      <Link to="/about">Preferences</Link>
      <Link to="/about">About</Link>
      <Link to="/about">MyRx</Link>
      <Link to="/login">Logout</Link>
    </div>

  );
}

export default SideNav;
