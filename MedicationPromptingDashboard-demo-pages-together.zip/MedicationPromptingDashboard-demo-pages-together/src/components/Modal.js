import React, { useState, useEffect } from 'react';
import Modal from 'react-modal';
import './Modal.css';
import { unmountComponentAtNode } from 'react-dom';

const dosage = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
const frequency = ["Mon", "Tue", "Wed", "Thur", "Fri", "Sat", "Sun"]
const times = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
const timeIndicator = ["am", "pm"]

export const MedModal = (props) => {
    const { formdata, onChange, onClose, onOpen } = props
    const [inputMedText, setMedText] = useState(formdata.medText || '')
    const [checkedArr, setCheckedArr] = useState(formdata.daysArr || [])
    const [preferredTimes, setPreferredTimes] = useState(formdata.timesArr || [])

    /* set the value states of <select /> */
    const [numberDosage, setNumberDosage] = useState(formdata.dose || 1)
    const time1 = ((preferredTimes[0] || '')).toString(0)
    const [timeValue, setTimeValue] = useState((parseInt((time1.substring(0, 1))) || 8))
    const [timeIndValue, setTimeIndValue] = useState((time1.substring((time1.length - 2), (time1.length))) || "am")
    var timeStr = timeValue + ":00 " + timeIndValue
    const [unorderedDays, setUnorderedDays] = useState([])

    useEffect(() => {
        if (!preferredTimes.includes(timeStr)) {
            //setPreferredTimes(preferredTimes => [...preferredTimes, timeStr])
            setPreferredTimes([timeStr])
        }
    }, [timeStr]);


    useEffect(() => {
        if (unorderedDays.length !== 0) {
            let indexArr = unorderedDays.map(o => frequency.indexOf(o))
            indexArr.sort((a, b) => a - b)
            setCheckedArr(indexArr.map(o => frequency[o]))
        }
    }, [unorderedDays]);

    function checkOpen() {
        onOpen()
    }

    function displayHeader() {
        if (formdata.isNew === true) {
            return ("Add a Medication")
        }
        else {
            return ("Edit a Medication")
        }
    }

    function handleMedNameChange(evt) {
        setMedText(evt.target.value)

    }

    function sortDaysArr() {
        let indexArr = checkedArr.map(o => frequency.indexOf(o))

        indexArr.sort((a, b) => a - b)

        console.log(indexArr.map(o => frequency[o]))
        return indexArr.map(o => frequency[o])
    }

    function handleCheckChange(evt) {
        const checkbox = evt.target

        if (checkbox.checked === true) {
            setUnorderedDays(unorderedDays => [...unorderedDays, checkbox.value])
            //setCheckedArr(checkedArr => [...checkedArr, checkbox.value])
        }
        else {
            let tempArr = [...unorderedDays]
            const remove = tempArr.indexOf(checkbox.value)

            tempArr.splice(remove, 1)
            setUnorderedDays(tempArr)
        }

    }

    const handleDosageChange = (evt) => {
        setNumberDosage(evt.target.value)
    }

    const handleTimeChange = (evt) => {
        const currentTime = evt.target.value


        setTimeValue(currentTime)

        if (timeStr === '') {
            timeStr = currentTime + ":00 "
        }
        else {
            timeStr = currentTime + ":00 " + timeIndValue
        }


    }

    const handleTimeIndicatorChange = (evt) => {
        const currTimeInd = evt.target.value

        setTimeIndValue(currTimeInd)

        if (timeStr.includes("am") || timeStr.includes("pm")) {
            timeStr = timeValue + ":00 " + currTimeInd
        }
        else {
            timeStr += currTimeInd
        }


    }


    function OKHandler() {
        const data = { inputMedText, checkedArr, preferredTimes, numberDosage }

        if (checkAllFilled() === true) {
            //sortDaysArr()
            onChange(data)
        }
        else {
            window.alert('Not all fields are complete!')
        }
        console.log('modal input med:', inputMedText)
        console.log('modal checked arr:', checkedArr)
        // console.log('modal dose num:',numberDosage)
        // console.log('modal time pref:',preferredTimes)

    }


    function closeHandler() {
        onClose()
    }

    function checkAllFilled() {
        if (inputMedText !== '' && checkedArr.length !== 0) {
            return true
        }
    }


    return (
        <Modal isOpen={checkOpen} className="Med-Modal" >
            <h1 className="Modal-Header">
                {displayHeader()}
            </h1>
            <div className="MedModalBody">
                <div className="MedName-Modal">
                    <label for="Med-Text" >Medication Name: </label>
                    <input type="text" className="Med-Text" placeholder="Ex: Tylenol" onChange={e => handleMedNameChange(e)} defaultValue={((inputMedText.length === 0) ? '' : inputMedText)}>
                    </input>
                </div>
                <div className="Frequency">
                    <label for="Frequency">Days: </label>
                    {
                        frequency.map(o =>
                            <label for="{o}" className="freqLabels">{o}
                                <input type="checkbox" value={o} onClick={e => handleCheckChange(e)} defaultChecked={(checkedArr.includes(o) ? true : false)} />
                            </label>)
                    }
                </div>
                <div className="Number-Dosage">
                    <label for="NumberTimes">How many times will you take this per day?</label>
                    <select className="NumberTimes" value={numberDosage} onChange={e => handleDosageChange(e)} >
                        {dosage.map(o => <option value={o}>{o}</option>)}
                    </select>
                </div>
                <div className="Preferred-Time">
                    <label for="Reminder-Time">Preferred Reminder Time: </label>
                    <select className="Reminder-Time" value={timeValue} onChange={e => handleTimeChange(e)}>
                        {times.map(o => <option value={o}>{o + ":00"}</option>)}
                    </select>
                    <select className="Time-indicator" value={timeIndValue} onChange={e => handleTimeIndicatorChange(e)} >
                        {timeIndicator.map(o => <option value={o}>{o.toUpperCase()}</option>)}
                    </select>
                </div>
                <div className="Modal-buttons">
                    <button className="CloseModal" onClick={() => { closeHandler() }}>Cancel</button>
                    <button className="UpdateButton" onClick={() => { OKHandler() }}>OK</button>
                </div>
            </div>
        </Modal>
    );
}