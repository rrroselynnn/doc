import React from 'react';
import Card from 'react-bootstrap/Card';
import Edit from '../Edit (Acc Orange).png';
import Delete from '../Delete (Acc Orange).png';
import './Card.css';

export const MedCard = (props) => {
    const { cardData, index, onEdit, onDelete } = props

    function onDeleteButtonClick() {
        onDelete(index)
    }

    function onEditButtonClick() {
       onEdit(index)
    }


    return (
        <Card className="Card-Container" style={{ width: '80rem' }} >
            <Card.Body className="Card-Body">
                <p className="Med-name">
                    {cardData.medName}
                </p>
                <p className="Med-frequency">
                    {cardData.days}
                </p>
                <button type="button" className="Edit-Button" onClick={onEditButtonClick}>
                    <p className="Edit-text" >
                        Edit
                    </p>
                    <img src={Edit} className="Med-edit" alt="edit" />
                </button>
                <button type="button" className="Delete-Button" onClick={onDeleteButtonClick}>
                    <p className="Delete-text" >
                        Delete
                            </p>
                    <img src={Delete} className="Med-delete" alt="delete" />
                </button>
            </Card.Body>

        </Card>

    );
}

        
