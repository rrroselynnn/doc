import React from 'react';
import Modal from 'react-modal';
import './DeleteAlert.css';

export const DeleteAlert = (props) => {
    const { show, onOKClick, onCancelClick } = props

    function handleOKClick() {
        onOKClick()
    }

    function handleCancelClick() {
        onCancelClick()
    }

    return (
        <Modal className="Delete-Alert" isOpen={show}>
            <div className="Delete-Text">
                You are about to delete this medication! Are you sure you want to continue?
            </div>
            <div className="Delete-Buttons">
                    <button className="CancelDelete" onClick={handleCancelClick}>Cancel</button>
                    <button className="OKDelete" onClick={handleOKClick}>OK</button>
            </div>
        </Modal>
    );
}