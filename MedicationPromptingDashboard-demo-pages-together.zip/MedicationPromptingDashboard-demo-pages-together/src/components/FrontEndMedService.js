const axios = require('axios');

export default class FrontendMedicationService {

    /**
     * get all medications for a user
     * @param user: user id 
     * @returns {Q.Promise<Q.Promise<string> | Promise<* | string> | * | TypeError>}
     */

    static async getMedications(user) {
        return axios({
            url: 'http://localhost:8000/medications',
            method: 'GET',
            json: true,
            params: {
                user,
            },
        }).then((response) => {
            console.log(JSON.stringify(response.data))
            return response.data;
        }).catch(error => {
            console.log(error);
            throw(error);
        });
    }

    /**
     * search for a user's medication
     * @param user: user id 
     * @param med: med name
     * @returns {Q.Promise<Q.Promise<any> | Promise<*> | * | undefined>}
     */

    static async searchMedication(user, med) {
        return axios({
            url: 'http://localhost:8000/medications',
            method: 'GET',
            json: true,
            params: {
                user,
                med,
            }
        }).then((response) => {
            console.log(JSON.stringify(response.data)) 
            return response;
        }).catch(error => {
            console.log(error);
            throw(error);
        });
    }


    /**
     * create medication for a user
     * @param user_id user ID
     * @param email user email
     * @param med medication name
     * @param doses list of json doses (days/time/dose id)
     * @returns {Q.Promise<Q.Promise<string> | Promise<* | string> | * | TypeError>}
     * createMedication(user_id, email, med, doses)
     * data: {
                user_id,
                email,
                medication: [{
                    name: med,
                    doses: [json],
                }]
            },
     */
    
    static async createMedication(user_data) {

        return axios({
            url: 'http://localhost:8000/medications',
            method: 'post',
            json: true,
            headers: { 
                'Content-Type': 'application/json',
                  'Access-Control-Allow-Origin': '*'},
            data: {
                user_data,
            },
        }).then((response) => {
            return response
            }).catch(error => { 
                console.log(error);
                throw(error);
                
        })
    }
}
