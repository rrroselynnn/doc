import React from 'react';
import logo from '../OptumLogo.png';
import './CustHeader.css'


export const CustHeader = (TitleStr) => {
    return (
        <header className='CustHeader'>
            <div className="header-Container" alt="Header">
                <img src={logo} className="CustHeader-logo" alt="Optum logo" />
                <p name="Product Name" alt="Page Title">{TitleStr}</p>
            </div>
        </header>
    );
}


export default CustHeader;