
import React from 'react';
import { Route, IndexRoute } from 'react-router';

import MedicationAdding from './MedicationAdding';
import Login from './LoginPage'

const Routes = [
    {
        path: '/medications',
        sidebarName: 'Medications',
        navbarName: 'Medications',
        // icon: LocalHospital,
        component: MedicationAdding
    },
    {
        path: '/about',
        sidebarName: 'About',
        navbarName: 'About',
        // icon: Info,
        component: About
    },

    {
        path: '/logout',
        sidebarName: 'Logout',
        navbarName: 'Logout',
        // icon: ExitToApp,
        component: Login
    }
];

export default Routes;
